const gameScene = new Phaser.Scene('Game');

gameScene.init = function () { };

gameScene.preload = function () {
    this.load.image('ground', 'assets/images/ground.png');
    this.load.image('platform', 'assets/images/platform.png');
    this.load.image('block', 'assets/images/block.png');
    this.load.image('goal', 'assets/images/gorilla.png');
    this.load.image('barrel', 'assets/images/barrel.png');

    this.load.spritesheet('player', 'assets/images/player_spritesheet.png', {
        frameWidth: 28,
        frameHeight: 30,
        margin: 1,
        spacing: 1
    });

    this.load.spritesheet('fire', 'assets/images/fire_spritesheet.png', {
        frameWidth: 20,
        frameHeight: 21,
        margin: 1,
        spacing: 1
    });
};

gameScene.create = function () { };

gameScene.update = function () { };

const config = {
    type: Phaser.AUTO,
    width: 360,
    height: 640,
    scene: gameScene,
    pixelArt: false,
    title: 'Platformer game'
};

const game = new Phaser.Game(config);
