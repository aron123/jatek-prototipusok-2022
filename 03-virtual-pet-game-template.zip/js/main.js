const gameScene = new Phaser.Scene('Game');

gameScene.init = function () {};

gameScene.preload = function () {
    this.load.image('backyard', 'assets/backyard.png');
    this.load.image('apple', 'assets/apple.png');
    this.load.image('candy', 'assets/candy.png');
    this.load.image('rotate', 'assets/rotate.png');
    this.load.image('toy', 'assets/rubber_duck.png');
};

gameScene.create = function () {};

const config = {
    type: Phaser.AUTO,
    width: 360,
    height: 640,
    backgroundColor: '#ffffff',
    pixelArt: false,
    scene: gameScene
};

const game = new Phaser.Game(config);
