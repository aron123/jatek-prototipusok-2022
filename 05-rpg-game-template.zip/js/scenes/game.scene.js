const gameScene = new Phaser.Scene('Game');

gameScene.init = function () {
  this.score = 0;

  this.playerSpeed = 160;
}

gameScene.create = function () {
  this.scene.launch('UI');

  this.player = this.add.sprite(32, 32, 'characters', 0);
  this.physics.add.existing(this.player);
  this.player.setScale(2);
  this.player.body.setCollideWorldBounds(true);

  this.cursors = this.input.keyboard.createCursorKeys();
}

gameScene.update = function () {
  this.updatePlayer();
}

gameScene.updatePlayer = function () {
  this.player.body.setVelocity(0);

  if (this.cursors.left.isDown) {
    this.player.flipX = false;
    this.player.body.setVelocityX(-this.playerSpeed);
  } else if (this.cursors.right.isDown) {
    this.player.flipX = true;
    this.player.body.setVelocityX(this.playerSpeed);
  }

  if (this.cursors.up.isDown) {
    this.player.body.setVelocityY(-this.playerSpeed);
  } else if (this.cursors.down.isDown) {
    this.player.body.setVelocityY(this.playerSpeed);
  }
};
