const bootScene = new Phaser.Scene('Boot');

bootScene.preload = function () {
  this.load.spritesheet('items', 'assets/items.png', {
    frameWidth: 32,
    frameHeight: 32
  });

  this.load.spritesheet('characters', 'assets/characters.png', {
    frameWidth: 32,
    frameHeight: 32
  });
};

bootScene.create = function () {
  this.scene.start('Game');
};
